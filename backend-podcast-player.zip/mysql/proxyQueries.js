

module.exports = {
  getEpisodeCache,
  addEpisodeCache,
  getSearchCache,
  addSearchCache,
};
