const salt = "tijsk";

module.exports = { salt };
