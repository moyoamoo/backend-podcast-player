const endPoint = "https://api.taddy.org";
const userID = "1098";
const apiKey =
  "1f294e69b341b027256c07eff203bbc5b4ca73be67a8f8f8751fdfeb3fa8412948f7a07664e77b3e6585d9109aedb3c88a";
const geoApiKey = "662e10c9b49d9397261820khvc354ff";
module.exports = { endPoint, userID, apiKey, geoApiKey };
